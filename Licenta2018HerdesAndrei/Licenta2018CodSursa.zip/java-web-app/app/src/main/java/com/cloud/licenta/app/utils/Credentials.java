package com.cloud.licenta.app.utils;

public class Credentials {

	public static final String INSTANCE_NAME = "spring-boot-webapp:europe-west3:emotio-recognition-instance";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "1234";

}
