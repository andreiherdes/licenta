package com.cloud.licenta.app;

public class AppApplicationTests {

}
